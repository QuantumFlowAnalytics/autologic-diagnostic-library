AUTOLOGIC ACADEMY PWA MVP 0.4.0
Integrated generic DTC reference database

CONTENTS
- index.html: searchable interface
- app.js: search, filtering and record display
- data/generic.min.json: 9,533 imported generic DTC records
- manifest.webmanifest, icon.svg, sw.js: installable PWA shell
- This is a static website. No server-side database is required.

WHAT WORKS
- Search by DTC, English title/description, causes, symptoms and component names.
- Filter by Powertrain, Body, Chassis and Network categories.
- Open a record to see available causes, symptoms, affected components, generic repair notes, flags, related codes and source links.
- Responsive mobile layout.
- PWA shell can be installed when served over HTTPS.
- Source provenance is retained in the dataset.

IMPORTANT LIMITS
- This is a GENERIC DTC reference, not a manufacturer-specific diagnostic system.
- It does not authenticate Payhip customers or restrict access. Anyone with the public website URL can access the data.
- The service worker caches the application shell, not the 32 MB dataset. First load requires internet access.
- Source records are imported as supplied. AutoLogic has not independently re-verified every entry.
- Do not present source review dates as AutoLogic verification.
- Never turn a generic code description into a vehicle-specific pass/fail test or repair instruction.
- Vehicle-specific procedures need exact vehicle/module applicability and traceable OEM or properly licensed technical sources.
- SRS/pyrotechnic and EV/hybrid high-voltage work must follow OEM safety procedures and appropriate training.

PUBLISHING OPTION: GITHUB PAGES
1. Create or open an AutoLogic GitHub repository.
2. Upload the CONTENTS of this folder, keeping the data folder and its file intact.
3. In repository Settings > Pages, choose deploy from branch and select the main branch and root folder.
4. Wait for GitHub Pages to publish the site, then open the published HTTPS address.
5. Test on a phone: search P0300, search a symptom, select a record, open a source link, and test category filters.
6. Add the published URL to the Payhip product/member welcome area.
7. Do not describe the library as private or members-only. This build has no login or entitlement check.

PAYHIP ACCESS CONTROL
Payhip checkout/download delivery is separate from this static site. To make a paid-only library, put the database behind a proper authenticated service or use a genuinely protected member platform. A hidden URL is not access control. Do not upload paid customer data or personal information into this public dataset.

DATA ATTRIBUTION
OBD-II code data: obdex (https://github.com/foerbsnavi/obdex), CC0-1.0.
The source repository states that generic DTC data is CC0-1.0. Check the repository's current data licence and source notices before each commercial release. Repository software may have a separate licence.

RELEASE
AutoLogic PWA MVP 0.4.0
Built 26 November 2026
Imported records: 9,533
Unique codes: 9,533
JSON data file: approximately 31.7 MB
