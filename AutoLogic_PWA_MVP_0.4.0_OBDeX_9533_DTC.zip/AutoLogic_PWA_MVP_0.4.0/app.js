(()=>{"use strict";
const $=id=>document.getElementById(id), PAGE=40;
let records=[],filtered=[],shown=0,selected=null;
const safe=s=>String(s??"");
const en=v=>typeof v==="string"?v:(v&&v.en)||"";
const arr=v=>Array.isArray(v)?v:[];
function searchable(r){return [r.code,r.category,en(r.title),en(r.description),...arr(r.affected_components),...arr(r.common_causes).flatMap(x=>typeof x==="string"?[x]:Object.values(x||{})),...arr(r.symptoms).flatMap(x=>typeof x==="string"?[x]:Object.values(x||{}))].join(" ").toLowerCase()}
function esc(s){return safe(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function listSection(title,items){if(!arr(items).length)return "";return `<h3>${esc(title)}</h3><ul>${items.map(x=>`<li>${esc(typeof x==="string"?x:en(x)||JSON.stringify(x))}</li>`).join("")}</ul>`}
function renderDetail(r){
 selected=r;const refs=arr(r.references),sources=arr(r.sources),related=arr(r.related_codes),components=arr(r.affected_components),flags=arr(r.flags);
 $("detail").innerHTML=`<div class="meta">${esc(r.category)} · reviewed ${esc(r.reviewed||"date not supplied")}</div><h2>${esc(r.code)} · ${esc(en(r.title)||"Untitled reference")}</h2><p>${esc(en(r.description)||"No English description supplied.")}</p>
 ${listSection("Affected components",components)}
 ${listSection("Common causes",r.common_causes)}
 ${listSection("Symptoms",r.symptoms)}
 ${listSection("Generic repair notes",r.repair)}
 ${flags.length?`<h3>Record flags</h3>${flags.map(x=>`<span class="tag">${esc(typeof x==="string"?x:JSON.stringify(x))}</span>`).join("")}`:""}
 ${related.length?`<h3>Related codes</h3><p>${related.map(x=>{let c=typeof x==="string"?x:(x.code||JSON.stringify(x));return `<button class="secondary related" data-code="${esc(c)}" type="button">${esc(c)}</button>`}).join(" ")}</p>`:""}
 ${sources.length?`<h3>Source links</h3><ul>${sources.map(x=>{let u=typeof x==="string"?x:(x.url||x.uri||"");let label=typeof x==="string"?x:(x.title||u);return u?`<li><a href="${esc(u)}" target="_blank" rel="noopener">${esc(label)}</a></li>`:`<li>${esc(label)}</li>`}).join("")}</ul>`:""}
 ${refs.length?listSection("References",refs):""}
 <p class="meta">Generic dataset only. Verify exact vehicle/module applicability using current OEM service information.</p>`;
 $("detail").querySelectorAll(".related").forEach(b=>b.addEventListener("click",()=>{$("q").value=b.dataset.code;apply();}));
}
function render(){
 const slice=filtered.slice(0,shown);$("results").innerHTML=slice.map(r=>`<button type="button" class="result" data-code="${esc(r.code)}" aria-current="${selected?.code===r.code}"><span class="code">${esc(r.code)}</span><span class="rtitle">${esc(en(r.title)||"Untitled")}</span><div class="meta">${esc(r.category)}</div></button>`).join("")||`<div class="empty">No matching records. Try a code such as P0300 or a broader search term.</div>`;
 $("results").querySelectorAll(".result").forEach(b=>b.addEventListener("click",()=>{const r=records.find(x=>x.code===b.dataset.code);renderDetail(r);render();}));
 $("status").textContent=`${filtered.length.toLocaleString("en-GB")} matching codes · showing ${Math.min(shown,filtered.length).toLocaleString("en-GB")}`;
 $("more").innerHTML=shown<filtered.length?`<button id="loadMore" type="button">Load next ${Math.min(PAGE,filtered.length-shown)} results</button>`:"";
 $("loadMore")?.addEventListener("click",()=>{shown+=PAGE;render();});
}
function apply(){const q=$("q").value.trim().toLowerCase(),cat=$("category").value;filtered=records.filter(r=>(!cat||r.category===cat)&&(!q||searchable(r).includes(q)));shown=PAGE;render();}
$("q").addEventListener("input",apply);$("category").addEventListener("change",apply);$("clear").addEventListener("click",()=>{$("q").value="";$("category").value="";selected=null;$("detail").innerHTML="<p>Select a code to inspect its reference information.</p>";apply();});
fetch("data/generic.min.json").then(r=>{if(!r.ok)throw Error("HTTP "+r.status);return r.json()}).then(data=>{if(!Array.isArray(data))throw Error("Dataset format is not a list");records=data;apply();}).catch(e=>{$("status").textContent="Could not load diagnostic records."; $("results").innerHTML=`<div class="empty">Dataset loading failed: ${esc(e.message)}<br>Check that data/generic.min.json is present beside this app and that it is hosted over HTTP/HTTPS.</div>`;});
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
})();